﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Model
{
    public interface ICarRepository
    {
        IEnumerable<Car> AllCar  { get; }
    }
}

