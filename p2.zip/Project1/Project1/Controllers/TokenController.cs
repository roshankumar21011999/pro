﻿//using System;
//using System.Collections.Generic;
//using System.IdentityModel.Tokens.Jwt;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using Microsoft.IdentityModel.Tokens;
//using System.Security.Claims;
//using Microsoft.EntityFrameworkCore;
//using Project1.Model;

//namespace TheMatch.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class TokenController : ControllerBase
//    {
//        public IConfiguration _configuration;
//        private readonly AppDbContext _context;



//        public object JwtRegisteredClaimNames { get; private set; }
//        public object Key { get => key; set => key = value; }

//        public TokenController(IConfiguration config, AppDbContext context)
//        {
//            _configuration = config;
//            _context = context;
//        }



//        [HttpPost]
//        public async Task Post(Order _userData)
//        {
//            if (_userData != null && _userData.EmailId != null && _userData.Password != null)
//            {
//                var user = await GetUser(_userData.EmailId, _userData.Password);



//                if (user != null)
//                {
//                    var claims = new[]
//                    {
//                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),  
//                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()), 
//                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),

//                        new Claim("EmailId",user.EmailId),
//                          new Claim("Password",user.Password)
//                    };



//                }
//            }
//        }
//        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
//        var signIn = new SigningCredentials(Key, SecurityAlgorithms.HmacSha256);
//        var token = new JwtSecurityToken(_configuration["Jwt:Issuer"], _configuration["Jwt:Audience"], claims, expires: DateTime.UtcNow.AddDays(1), signingCredentials: signIn);
//                            return Ok(new JwtSecurityTokenHandler().WriteToken(token)); 
//        }                
//    else                
//    {                     
//    return BadRequest("Invalid credentials");
//}                        
//else             
//{                 
//return BadRequest();             }         
//}           
//private async Task GetUser(string email, string password) { return await _context.UserInfo.FirstOrDefaultAsync(u => u.Email == email && u.Password == password); }     } } 
//    }
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Project1.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;





namespace Project1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private readonly AppDbContext _context;
        public TokenController(IConfiguration config, AppDbContext context)
        {
            _configuration = config;
            _context = context;
        }
        [HttpPost]
        public async Task<Object> Post(Order _userData)
        {
            if (_userData != null && _userData.EmailId != null && _userData.Password != null)
            {
                var user = await GetUser(_userData.EmailId, _userData.Password);
                if (user != null)
                {
                    var claims = new[]
{
                    new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),


                    new Claim("Email", user.EmailId),
                    new Claim("Password", user.Password)
                };
                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                    var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);





                    var token = new JwtSecurityToken(_configuration["Jwt:Issuer"],
                        _configuration["Jwt:Audience"], claims,
                        expires: DateTime.UtcNow.AddDays(1),
                        signingCredentials: signIn);





                    return Ok(new JwtSecurityTokenHandler().WriteToken(token));
                }
                else { return BadRequest("Invalid credentials"); }
            }
            else { return BadRequest(); }
        }
        private async Task<Order> GetUser(string email, string password)
        {
            return await _context.orders.FirstOrDefaultAsync(u => u.EmailId == email && u.Password == password);
        }
    }
}