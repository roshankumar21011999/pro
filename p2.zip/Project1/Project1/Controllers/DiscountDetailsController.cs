﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project1.Model;

namespace Project1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DiscountDetailsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public DiscountDetailsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/DiscountDetails
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DiscountDetail>>> GetdiscountDetails()
        {
            return await _context.discountDetails.ToListAsync();
        }

        // GET: api/DiscountDetails/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DiscountDetail>> GetDiscountDetail(int id)
        {
            var discountDetail = await _context.discountDetails.FindAsync(id);

            if (discountDetail == null)
            {
                return NotFound();
            }

            return discountDetail;
        }

        // PUT: api/DiscountDetails/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutDiscountDetail(int id, DiscountDetail discountDetail)
        {
            if (id != discountDetail.DiscountId)
            {
                return BadRequest();
            }

            _context.Entry(discountDetail).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DiscountDetailExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/DiscountDetails
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<DiscountDetail>> PostDiscountDetail(DiscountDetail discountDetail)
        {
            _context.discountDetails.Add(discountDetail);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDiscountDetail", new { id = discountDetail.DiscountId }, discountDetail);
        }

        // DELETE: api/DiscountDetails/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<DiscountDetail>> DeleteDiscountDetail(int id)
        {
            var discountDetail = await _context.discountDetails.FindAsync(id);
            if (discountDetail == null)
            {
                return NotFound();
            }

            _context.discountDetails.Remove(discountDetail);
            await _context.SaveChangesAsync();

            return discountDetail;
        }

        private bool DiscountDetailExists(int id)
        {
            return _context.discountDetails.Any(e => e.DiscountId == id);
        }
    }
}
