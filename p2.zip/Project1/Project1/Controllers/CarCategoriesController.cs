﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project1.Model;

namespace Project1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarCategoriesController : ControllerBase
    {
        private readonly AppDbContext _context;

        public CarCategoriesController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/CarCategories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CarCategorie>>> GetcarCategories()
        {
            return await _context.carCategories.ToListAsync();
        }

        // GET: api/CarCategories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CarCategorie>> GetCarCategorie(int id)
        {
            var carCategorie = await _context.carCategories.FindAsync(id);
            carCategorie.cars = _context.cars.Where(c => c.CatgoriesId == id).ToList();

            if (carCategorie == null)
            {
                return NotFound();
            }

            return carCategorie;
        }

        // PUT: api/CarCategories/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCarCategorie(int id, CarCategorie carCategorie)
        {
            if (id != carCategorie.CatgoriesId)
            {
                return BadRequest();
            }

            _context.Entry(carCategorie).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CarCategorieExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CarCategories
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPost]
        public async Task<ActionResult<CarCategorie>> PostCarCategorie(CarCategorie carCategorie)
        {
            _context.carCategories.Add(carCategorie);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCarCategorie", new { id = carCategorie.CatgoriesId }, carCategorie);
        }

        // DELETE: api/CarCategories/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<CarCategorie>> DeleteCarCategorie(int id)
        {
            var carCategorie = await _context.carCategories.FindAsync(id);
            if (carCategorie == null)
            {
                return NotFound();
            }

            _context.carCategories.Remove(carCategorie);
            await _context.SaveChangesAsync();

            return carCategorie;
        }

        private bool CarCategorieExists(int id)
        {
            return _context.carCategories.Any(e => e.CatgoriesId == id);
        }
    }
}
